from transformers import DistilBertTokenizer, DistilBertForSequenceClassification, AdamW, \
    get_linear_schedule_with_warmup
from torch.utils.data import TensorDataset, random_split, DataLoader, RandomSampler, SequentialSampler
from sklearn import metrics

import torch.nn.functional as F
import numpy as np
import random
import pandas as pd
import os
import torch


def extract_label_vector(label, total_labels):
    labels = np.zeros(total_labels)
    labels[label] = 1
    return labels.tolist()


def compute_f1_macro(out, pred):
    probs = F.softmax(pred, dim=1)
    pred = torch.argmax(probs, dim=1)
    out = torch.argmax(out, dim=1)
    return metrics.f1_score(pred, out, average='macro')


def compute_precision(out, pred):
    probs = F.softmax(pred, dim=1)
    pred = torch.argmax(probs, dim=1)
    out = torch.argmax(out, dim=1)
    return metrics.precision_score(pred.numpy(), out.numpy(), average='micro')


def compute_recall(out, pred):
    probs = F.softmax(pred, dim=1)
    pred = torch.argmax(probs, dim=1)
    out = torch.argmax(out, dim=1)
    return metrics.recall_score(pred.numpy(), out.numpy(), average='micro')


def get_accuracy_from_logits(logits, labels):
    probs = F.softmax(logits, dim=1)
    output = torch.argmax(probs, dim=1)
    labels = torch.argmax(labels, dim=1)
    acc = (output == labels).float().mean()
    return acc


def get_pred(logits):
    probs = F.softmax(logits, dim=1)
    return torch.argmax(probs, dim=1)


def submit_csv(model, tokenizer, test_data, id_to_label):
    preds = np.zeros(len(test_data))
    model.eval()

    for i, row in test_data.iterrows():
        inputs = tokenizer(row.title, return_tensors="pt")
        model.to('cpu')
        with torch.no_grad():
            logits = model(**inputs).logits
            preds[i] = get_pred(logits)

    csv_data = pd.DataFrame({
        'id': test_data.id.values,
        'lib': preds.astype(int)
    })

    csv_data.lib = csv_data.lib.map(lambda x: id_to_label[x])
    path = os.path.join(os.getcwd(), "submission.csv")
    csv_data.to_csv(path, index=False)

    print("Submission successful!")


def train():
    if torch.cuda.is_available():
        device = torch.device("cuda")
        print(f'Using GPU : {torch.cuda.get_device_name(0)}')
    else:
        device = torch.device("cpu")
        print(f'Using CPU')

    path_to_train_data = './train.csv'
    path_to_test_data = './test.csv'

    train_data = pd.read_csv(path_to_train_data)
    test_data = pd.read_csv(path_to_test_data)

    label_to_id = {k: v for v, k in enumerate(set(train_data.lib))}
    id_to_label = {v: k for k, v in label_to_id.items()}

    train_data.lib = train_data.lib.map(lambda x: label_to_id[x])
    train_data['labels'] = train_data.lib.map(lambda x: extract_label_vector(x, len(label_to_id.keys())))

    text_data = train_data.title.values
    labels_data = list(train_data.labels)

    model_name = 'distilbert-base-uncased'
    tokenizer = DistilBertTokenizer.from_pretrained(model_name)

    input_ids = []
    attention_masks = []

    for text in text_data:
        encoded_dict = tokenizer.encode_plus(
            text,
            add_special_tokens=True,
            max_length=128,
            pad_to_max_length=True,
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt')
        input_ids.append(encoded_dict['input_ids'])
        attention_masks.append(encoded_dict['attention_mask'])

    input_ids = torch.cat(input_ids, dim=0)
    attention_masks = torch.cat(attention_masks, dim=0)
    labels_tensor = torch.tensor(labels_data)

    val_size = 0.1

    dataset = TensorDataset(input_ids, attention_masks, labels_tensor)
    train_dataset, val_dataset = random_split(dataset, [1 - val_size, val_size])

    print(f'Train set : {len(train_dataset)}')
    print(f'Validation set : {len(val_dataset)}')

    batch_size = 64

    train_dataloader = DataLoader(
        train_dataset,
        sampler=RandomSampler(train_dataset),
        batch_size=batch_size)

    validation_dataloader = DataLoader(
        val_dataset,
        sampler=SequentialSampler(val_dataset),
        batch_size=batch_size)

    model = DistilBertForSequenceClassification.from_pretrained(
        model_name,
        problem_type="multi_class_classification",
        num_labels=len(label_to_id.keys()),
        output_attentions=False,
        output_hidden_states=False,
    )
    model.to(device)

    learning_rate = 4e-5
    epochs = 6

    optimizer = AdamW(model.parameters(),
                      lr=learning_rate)
    total_steps = len(train_dataloader) * epochs
    scheduler = get_linear_schedule_with_warmup(optimizer,
                                                num_warmup_steps=300,
                                                num_training_steps=total_steps)

    loss_function = torch.nn.CrossEntropyLoss()

    print('Training started...')

    np.random.seed(42)
    random.seed(42)
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)

    training_stats = []

    for epoch_i in range(epochs):
        print()
        print('#-----------------------#')
        print(f'     Epoch : {epoch_i + 1} / {epochs}')
        print('#-----------------------#')

        model.train()
        total_train_loss = 0

        for step, batch in enumerate(train_dataloader):
            batch_input_ids = batch[0].to(device)
            batch_input_mask = batch[1].to(device)
            batch_labels = batch[2].float().to(device)

            model.zero_grad()

            result = model(batch_input_ids,
                           attention_mask=batch_input_mask,
                           labels=batch_labels,
                           return_dict=True)

            logits = result.logits
            loss = loss_function(logits, batch_labels)

            total_train_loss += loss.item()

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)

            optimizer.step()
            scheduler.step()

        avg_train_loss = total_train_loss / len(train_dataloader)

        print(f'Average train loss : {avg_train_loss:.3f}')
        print()
        print('Validation started...')
        print()

        model.eval()

        total_eval_loss = 0
        total_eval_f1_macro = 0
        total_precision = 0

        for batch in validation_dataloader:
            batch_input_ids = batch[0].to(device)
            batch_input_mask = batch[1].to(device)
            batch_labels = batch[2].float().to(device)

            with torch.no_grad():
                result = model(batch_input_ids,
                               attention_mask=batch_input_mask,
                               labels=batch_labels,
                               return_dict=True)

            logits = result.logits
            loss = loss_function(logits, batch_labels)

            total_eval_loss += loss.item()

            logits = logits.detach().cpu()
            label_ids = batch_labels.to('cpu').detach()

            total_eval_f1_macro += compute_f1_macro(logits, label_ids)
            total_precision += compute_precision(logits, label_ids)

        avg_val_f1_macro = total_eval_f1_macro / len(validation_dataloader)
        avg_val_loss = total_eval_loss / len(validation_dataloader)
        avg_val_precision = total_precision / len(validation_dataloader)

        print(f'Average validation loss : {avg_val_loss:.3f}')
        print('Average validation metrics:')
        print('----------------')
        print(f'Precision : {avg_val_precision:.3f}')
        print(f'f1-score macro : {avg_val_f1_macro:.3f}')

        training_stats.append(
            {
                'epoch': epoch_i + 1,
                'train_loss': avg_train_loss,
                'valid_loss': avg_val_loss,
                'val_f1_macro': avg_val_f1_macro,
                'val_precision': avg_val_precision
            })

    print()
    print('Training finished...')

    submit_csv(model, tokenizer, test_data, id_to_label)


if __name__ == "__main__":
    train()
